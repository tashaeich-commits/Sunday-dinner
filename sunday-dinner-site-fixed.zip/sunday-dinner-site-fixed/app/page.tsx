'use client';

const journeySteps = [
  {
    title: 'Get Invited',
    description: 'Someone shares their invitation with you and unlocks your seat at the table.',
    icon: '✉️',
  },
  {
    title: 'View the Menu',
    description: 'At midnight on Friday, invited guests can see the weekly Sunday Dinner reveal.',
    icon: '🕛',
  },
  {
    title: 'Reserve Your Seat',
    description: 'Place your order before the table is full.',
    icon: '🍽️',
  },
  {
    title: 'Sunday Delivery',
    description: 'Dinner is delivered across the city on Sunday between 5–7 PM.',
    icon: '🚗',
  },
  {
    title: 'Invite Others',
    description: 'After you join, you receive your own invitation to share with others.',
    icon: '🤝',
  },
];

export default function HomePage() {
  return (
    <div className="min-h-screen bg-[#1A1A1A] text-[#F7F1E8]">
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,rgba(201,169,106,0.18),transparent_35%),linear-gradient(to_bottom,rgba(0,0,0,0.3),rgba(0,0,0,0.75))]" />
        <div
          className="absolute inset-0 opacity-20 bg-cover bg-center"
          style={{ backgroundImage: "url('https://images.unsplash.com/photo-1414235077428-338989a2e8c0?q=80&w=1600&auto=format&fit=crop')" }}
        />

        <div className="relative mx-auto flex min-h-[92vh] max-w-7xl flex-col justify-center px-6 py-16 md:px-10 lg:px-16">
          <div className="max-w-3xl">
            <p className="mb-4 inline-flex items-center rounded-full border border-[#C9A96A]/40 bg-[#C9A96A]/10 px-4 py-1 text-sm tracking-[0.22em] uppercase text-[#C9A96A]">
              Shared and delivered across the city every Sunday
            </p>

            <h1 className="font-serif text-5xl leading-tight sm:text-6xl md:text-7xl">
              Have you been invited to <span className="text-[#C9A96A]">Sunday Dinner</span>?
            </h1>

            <p className="mt-6 max-w-2xl text-lg leading-8 text-[#F7F1E8]/80 sm:text-xl">
              A weekly dining experience prepared and delivered across the city every Sunday.
            </p>

            <div className="mt-10 flex flex-col gap-4 sm:flex-row">
              <button
                onClick={() => {
                  const el = document.getElementById('how-it-works');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                className="inline-flex items-center justify-center rounded-2xl bg-[#C9A96A] px-7 py-4 text-base font-semibold text-[#1A1A1A] shadow-lg shadow-[#C9A96A]/20 transition hover:-translate-y-0.5"
              >
                How It Works
              </button>
            </div>

            <div className="mt-10">
              <p className="text-lg text-[#F7F1E8]/80">
                <strong>Have you already been invited?</strong>
              </p>

              <button className="mt-4 rounded-2xl border border-[#F7F1E8]/25 bg-white/5 px-7 py-4 text-base font-semibold text-[#F7F1E8] backdrop-blur-sm transition hover:bg-white/10">
                Enter Invitation Link or Code
              </button>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto grid max-w-7xl gap-10 px-6 py-20 md:px-10 lg:px-16">
        <div className="rounded-[2rem] border border-white/10 bg-gradient-to-br from-[#2B1D16] to-[#16110e] p-8 shadow-2xl shadow-black/30">
          <p className="mb-3 text-sm uppercase tracking-[0.22em] text-[#C9A96A]">Not invited yet</p>
          <h3 className="font-serif text-4xl leading-tight">You haven’t been invited yet.</h3>
          <p className="mt-6 text-lg leading-8 text-[#F7F1E8]/78">Seats at the table are shared through invitation.</p>
          <p className="mt-4 text-lg leading-8 text-[#F7F1E8]/78">
            Ask around. Someone you know may already have a seat at the table.
          </p>
          <p className="mt-4 text-lg leading-8 text-[#F7F1E8]/78">When they invite you, the menu will be revealed.</p>
        </div>
      </section>

      <section className="mx-auto grid max-w-7xl gap-12 px-6 py-20 md:px-10 lg:grid-cols-[1.1fr_0.9fr] lg:px-16">
        <div>
          <p className="mb-3 text-sm uppercase tracking-[0.22em] text-[#C9A96A]">The story</p>
          <h2 className="font-serif text-4xl leading-tight sm:text-5xl">Sunday Dinner has always been more than a meal.</h2>
        </div>

        <div className="space-y-5 text-lg leading-8 text-[#F7F1E8]/82">
          <p>
            It’s the moment the family gathers. The table fills. Stories are shared. And the kitchen slows down long enough for everyone to eat together.
          </p>
          <p>Sunday Dinner was created to bring that feeling back.</p>
          <p>
            Each week, one dinner is prepared, <span className="text-[#C9A96A]">shared and delivered across the city</span>.
          </p>
          <p>Everyone gathers in their own homes, but they’re a part of the same table.</p>
          <p>
            <span className="font-semibold text-[#F7F1E8]">But the table is small — for now.</span>
          </p>
          <p>Seats are limited, and the menu is revealed only through invitation.</p>
          <p>
            <span className="font-semibold text-[#F7F1E8]">You can only come to the table if you’ve been invited.</span>
          </p>
        </div>
      </section>

      <section id="how-it-works" className="border-y border-white/10 bg-[#221812]">
        <div className="mx-auto max-w-7xl px-6 py-20 md:px-10 lg:px-16">
          <div className="mb-12 max-w-3xl">
            <p className="mb-3 text-sm uppercase tracking-[0.22em] text-[#C9A96A]">How it works</p>
            <h3 className="font-serif text-4xl sm:text-5xl">Your journey to the table.</h3>
            <p className="mt-5 text-lg leading-8 text-[#F7F1E8]/75">
              Friday at midnight the menu is revealed. On Sunday, dinner is delivered across the city between 5–7 PM.
            </p>
          </div>

          <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-5">
            {journeySteps.map((step) => (
              <div
                key={step.title}
                className="rounded-3xl border border-white/10 bg-white/5 p-6 shadow-2xl shadow-black/20 backdrop-blur-sm"
              >
                <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-[#C9A96A]/15 text-2xl ring-1 ring-[#C9A96A]/30">
                  {step.icon}
                </div>
                <h4 className="font-serif text-2xl text-[#F7F1E8]">{step.title}</h4>
                <p className="mt-3 text-base leading-7 text-[#F7F1E8]/75">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <footer className="border-t border-white/10 px-6 py-8 md:px-10 lg:px-16">
        <div className="mx-auto flex max-w-7xl flex-col gap-3 text-sm text-[#F7F1E8]/60 sm:flex-row sm:items-center sm:justify-between">
          <p className="font-serif text-lg text-[#F7F1E8]">Sunday Dinner</p>
          <p>Shared and delivered across the city every Sunday.</p>
        </div>
      </footer>
    </div>
  );
}
