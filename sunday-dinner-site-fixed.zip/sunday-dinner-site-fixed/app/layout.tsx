import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Sunday Dinner',
  description: 'A weekly dining experience prepared and delivered across the city every Sunday.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
