# Sunday Dinner site

Deploy on Vercel as a Next.js app.

## Notes
- Uses Next.js 14.2.35
- Root directory should be the project root containing package.json
- No build or output directory overrides are needed in Vercel
